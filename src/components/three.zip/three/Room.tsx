import React, { useEffect } from "react";
import { useMyStore } from "../../system/My";
import * as THREE from 'three';

import createRenderer from "./Renderer";
import createCamera from "./Camera";
import createScene from "./Scene";
import createLights from "./Light";
import { CustomMeshObject, GLTFMeshObject } from "./MeshObject";
import { GLTFLoader } from "three/examples/jsm/Addons.js";
import Controller from "./Controller";
import { Player } from "./Player";

const Room: React.FC = () => {
    const config = useMyStore(state => state.config);
    const clock = new THREE.Clock();
    let delta = clock.getDelta();

    useEffect(() => {
        const canvas = document.getElementById('room') as HTMLCanvasElement;

        // Envinronments //
        const renderer = createRenderer(canvas);
        const camera = createCamera();
        const scene = createScene();
        const lights = createLights();
        const gltfLoader = new GLTFLoader();

        scene.add(camera);
        scene.add(...lights);

        // Objects //
        new CustomMeshObject({
            scene,
            name: 'land',
            position: new THREE.Vector3(0, -0.05, 0),
            geometry: new THREE.CylinderGeometry(50, 50, 0.1, 32, 1),
            pivotGround: false,
        })

        new CustomMeshObject({
            scene,
            name: 'stage',
            width: 7,
            height: 0.4,
            depth: 7,
            color: '#dddddd',
            render: true,
        })

        const floor = new CustomMeshObject({
            scene,
            name: 'floor',
            width: 4.4,
            height: 0.6,
            depth: 4.4,
            color: '#dddddd',
            render: true,
        })

        new CustomMeshObject({
            scene,
            name: 'sphere',
            refPosition: new THREE.Vector3(0, floor.height, 0),
            position: new THREE.Vector3(0, 1, 0),
            geometry: new THREE.SphereGeometry(1, 32, 32),
            material: new THREE.MeshStandardMaterial({color: '#ffffff'}),
            pivotGround: false,
            render: false,
        })

        new GLTFMeshObject({
            scene,
            name: 'table',
            loader: gltfLoader,
            source: '/table.glb',
            render: false,
        })

        // Agent //
        const player = new Player({
            scene,
            name: 'you',
            mass: 50,
            refPosition: new THREE.Vector3(0, floor.height, 0)
        });
        const controller = new Controller({agent: player});

        // Update Loop //
        const update = () => {
            delta = clock.getDelta();
            
            controller.move();

            controller.rotate(camera);

            renderer.render(scene, camera);

            renderer.setAnimationLoop(update);
        }

        update();

        // Events //
        const resizeHandler = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }

        const clickHandler = () => canvas.requestPointerLock();

        const pointerlockchangeHandler = () => {
            if(document.pointerLockElement === canvas){
                document.body.dataset.mode = 'game'; // <body data-mode="game">
                document.addEventListener('mousemove', controller.updateMouse);
            } else {
                document.body.dataset.mode = 'website'; // <body data-mode="website">
                document.removeEventListener('mousemove', controller.updateMouse);
            }
        }

        window.addEventListener('resize', resizeHandler);
        window.addEventListener('click', clickHandler);
        document.addEventListener('pointerlockchange', pointerlockchangeHandler);

        return (() => {
            window.removeEventListener('resize', resizeHandler);
            window.removeEventListener('click', clickHandler);
            document.removeEventListener('pointerlockchange', pointerlockchangeHandler);
        })

    }, [])

    return null;
}

export default Room;