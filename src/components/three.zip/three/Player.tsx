import { CapsuleGeometry, Mesh, MeshLambertMaterial } from "three";
import { ThreeObject, ThreeObjectType } from "./MeshObject";

interface PlayerType extends ThreeObjectType {
    mass: number
}

type directions = 'left' | 'right' | 'forward' | 'backward';

export class Player extends ThreeObject {
    mass: number
    mesh: Mesh
    isJumping: boolean

    constructor(info: PlayerType) {
        super(info);

        this.mass = info.mass || 0;
        this.position.y += (this.width + this.height) / 2;

        const geometry = new CapsuleGeometry(this.width / 2, this.height);
        const material = new MeshLambertMaterial({
            transparent: false,
            opacity: 1.0,
        })
        
        this.mesh = new Mesh(geometry, material);
        this.mesh.position.copy(this.position);
        this.mesh.rotation.copy(this.rotation);

        this.isJumping = false;

        info.scene.add(this.mesh);
    }

    walk = (value: number, direction: directions) => {
        let direct = {x: 0, z: 0};

        if (direction === 'left') {
            direct.x = -Math.sin(this.rotation.y + Math.PI / 2);
            direct.z = -Math.cos(this.rotation.y + Math.PI / 2);
        }
        if (direction === 'right') {
            direct.x = Math.sin(this.rotation.y + Math.PI / 2);
            direct.z = Math.cos(this.rotation.y + Math.PI / 2);
        }
        if (direction === 'forward') {
            direct.x = -Math.sin(this.rotation.y);
            direct.z = -Math.cos(this.rotation.y);
        }
        if (direction === 'backward') {
            direct.x = Math.sin(this.rotation.y);
            direct.z = Math.cos(this.rotation.y);
        }
        this.position.x += direct.x * value;
        this.position.z += direct.z * value;

        this.mesh.position.copy(this.position);
    }

    jump = () => {
        this.isJumping = true;
        
        setTimeout(() => {
            this.isJumping = false;
        }, 1000);
    }
}