import { Camera, Clock, Euler, Vector2, Vector3 } from "three";
import { Player } from "./Player";

interface ControllerType {
    agent: any
}

class Controller {
    clock: Clock

    keys: Record<string, boolean>;
    agent: Player;

    mousePos: Vector2;
    mouseDel: Vector2;

    euler: Euler;
    minPolarAngle: number;
    maxPolarAngle: number;

    constructor(info: ControllerType) {
        this.clock = new Clock();

        this.keys = {};
        this.agent = info.agent;

        this.mousePos = new Vector2();
        this.mouseDel = new Vector2();

        this.euler = new Euler(0, 0, 0, 'YXZ');
        this.minPolarAngle = 0;
        this.maxPolarAngle = Math.PI;

        window.addEventListener('keydown', event => {
            this.keys[event.code] = true;
        });

        window.addEventListener('keyup', event => {
            delete this.keys[event.code];
        })
    }

    move = () => {
        if (this.keys['KeyW'] || this.keys["ArrowUp"]){
            this.agent.walk(0.05, 'forward');
        }
        if (this.keys['KeyS'] || this.keys["ArrowDown"]){
            this.agent.walk(0.05, 'backward');
        }
        if (this.keys['KeyA'] || this.keys["ArrowLeft"]){
            this.agent.walk(0.05, 'left');
        }
        if (this.keys['KeyD'] || this.keys["ArrowRight"]){
            this.agent.walk(0.05, 'right');
        }
        if (this.keys['Space'] && !this.agent.isJumping){
            this.agent.jump();
        }
    }

    updateMouse = (e: MouseEvent) => {
        const delta = this.clock.getDelta();

        this.mouseDel.x = e.movementX / 2 * delta;
        this.mouseDel.x = e.movementY / 2 * delta;

        this.mousePos.x = 0;
        this.mousePos.y = 0;
    }

    rotate = (camera: Camera) => {
        this.euler.setFromQuaternion(camera.quaternion);
        this.euler.y -= this.mouseDel.x;
        this.euler.x -= this.mouseDel.y;
        this.euler.x = Math.max(
            Math.PI/2 - this.maxPolarAngle,
            Math.min(Math.PI/2 - this.minPolarAngle, this.euler.x)
        );

        this.mouseDel.x -= this.mouseDel.x * 0.2;
        this.mouseDel.y -= this.mouseDel.y * 0.2;
        if (Math.abs(this.mouseDel.x) < 0.1) this.mouseDel.x = 0;
        if (Math.abs(this.mouseDel.y) < 0.1) this.mouseDel.y = 0;
        
        camera.quaternion.setFromEuler(this.euler);

        // apply camer direction to the player direction
        this.agent.rotation.y = this.euler.y;

        // position
        camera.position.copy(this.agent.position.add(new Vector3(0, 1, 0)));
    }
}

export default Controller