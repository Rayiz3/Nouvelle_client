import { BoxGeometry, BufferGeometry, Euler, Group, Material, Mesh, MeshLambertMaterial, Object3D, Scene, TextureLoader, Vector3 } from 'three';
import { GLTF, GLTFLoader } from 'three/examples/jsm/Addons.js';

export interface ThreeObjectType {
    scene: Scene
    name: string
    width?: number
    height?: number
    depth?: number
    refPosition?: Vector3
    position?: Vector3
    rotation?: Euler
    scale?: Vector3
    render?: boolean
}

interface MeshObjectType extends ThreeObjectType {
    color?: string
}

interface CustomMeshObjectType extends MeshObjectType {
    geometry?: BufferGeometry
    material?: Material
    pivotGround?: boolean
}

interface GLTFMeshObjectType extends MeshObjectType {
    loader: GLTFLoader
    source: string
    mapSource?: string
}

export class ThreeObject {
    name: string
    width: number
    height: number
    depth: number
    refPosition: Vector3
    position: Vector3
    rotation: Euler
    scale: Vector3

    constructor(info: ThreeObjectType) {
        this.name = info.name;

        this.width = info.width || 1;
        this.height = info.height || 1;
        this.depth = info.depth || 1;

        this.refPosition = info.refPosition || new Vector3(0, 0, 0);
        this.position = info.position || new Vector3(0, 0, 0);
        this.rotation = info.rotation || new Euler(0, 0, 0);
        this.scale = info.scale || new Vector3( 1, 1, 1 );

        this.position.add(this.refPosition);
    }
}

export class MeshObject extends ThreeObject {
    color: string
    mesh: Object3D
    render: boolean

    constructor(info: MeshObjectType) {
        super(info);
        
        this.color = info.color || 'white';
        this.mesh = new Mesh();
        this.render = info.render ?? true;
    }
}

export class CustomMeshObject extends MeshObject {

    constructor(info: CustomMeshObjectType) {
        super(info);

        const geometry = info.geometry || new BoxGeometry(this.width, this.height, this.depth);
        const material = info.material || new MeshLambertMaterial({color: this.color});

        if (info.pivotGround ?? true) this.position.y += this.height / 2;

        // Mesh initialization
        this.mesh = new Mesh(geometry, material);
        this.mesh.name = this.name;
        this.mesh.castShadow = true;
        this.mesh.receiveShadow = true;
        this.mesh.position.copy(this.position);
        this.mesh.rotation.copy(this.rotation);
        this.mesh.scale.copy(this.scale);

        if (this.render) info.scene.add(this.mesh);
    }
}

export class GLTFMeshObject extends MeshObject {
    constructor(info: GLTFMeshObjectType) {
        super(info);
        info.loader.load(
            info.source,
            (gltf: GLTF) => {
                gltf.scene.traverse((child: Object3D) => {
                    if ((child as Mesh).isMesh) {
                        const mesh = child as Mesh;
                        mesh.castShadow = true;
                        mesh.receiveShadow = true;

                        const texture = info.mapSource? new TextureLoader().load(info.mapSource) : null;
                        mesh.material = new MeshLambertMaterial({
                            color: texture? "white" : this.color,
                            map: texture || (mesh.material as MeshLambertMaterial).map,
                        })

                        child.name = this.name;
                    }
                })

                // Mesh initialization
                this.mesh = gltf.scene as Group;
                this.mesh.name = this.name;
                this.mesh.position.copy(this.position);
                this.mesh.rotation.copy(this.rotation);
                this.mesh.scale.copy(this.scale);

                if (this.render) info.scene.add(this.mesh);
            },
            (xhr: ProgressEvent<EventTarget>) => {
                console.log((xhr.loaded / xhr.total * 100) + '% loaded');
            },
            (_: any) => {
                console.error('An error happened');
            }
        )
    }
}